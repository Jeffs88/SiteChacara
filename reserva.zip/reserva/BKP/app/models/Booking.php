<?php
class Booking {
    public static function createPre(array $data): int {
        $sql = "INSERT INTO bookings
            (status, date, start_time, end_time, people, kids_over2_counted, client_name, client_email, client_phone,
             additional_items, suggested_total, document_path, created_at)
            VALUES
            ('PENDING', ?, '08:00:00', ?, ?, 1, ?, ?, ?, ?, ?, ?, NOW())";
        $st = DB::pdo()->prepare($sql);
        $st->execute([
            $data['date'],
            sprintf('%02d:00:00', (int)$data['end_hour']),
            (int)$data['people'],
            $data['client_name'],
            $data['client_email'],
            $data['client_phone'],
            $data['additional_items'],
            (int)$data['suggested_total'],
            $data['document_path'],
        ]);
        return (int)DB::pdo()->lastInsertId();
    }

    public static function listBetween(string $start, string $end): array {
        $st = DB::pdo()->prepare("SELECT * FROM bookings WHERE date BETWEEN ? AND ? AND status IN ('PENDING','CONFIRMED') ORDER BY date ASC");
        $st->execute([$start, $end]);
        return $st->fetchAll() ?: [];
    }

    public static function listConfirmedUpcoming(): array {
        $st = DB::pdo()->query("SELECT * FROM bookings WHERE status='CONFIRMED' AND date >= CURDATE() ORDER BY date ASC");
        return $st->fetchAll() ?: [];
    }

    public static function listAll(int $limit=200): array {
        $st = DB::pdo()->prepare("SELECT * FROM bookings ORDER BY created_at DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }

    public static function find(int $id): ?array {
        $st = DB::pdo()->prepare("SELECT * FROM bookings WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public static function updateAdmin(int $id, array $data): void {
        $sql = "UPDATE bookings SET
            status=?,
            total_price=?,
            entry_paid=?,
            remaining=?,
            paid_status=?,
            additional_items=?,
            end_time=?,
            notes=?,
            updated_at=NOW()
        WHERE id=?";
        $st = DB::pdo()->prepare($sql);
        $st->execute([
            $data['status'],
            (int)$data['total_price'],
            (int)$data['entry_paid'],
            (int)$data['remaining'],
            $data['paid_status'],
            $data['additional_items'],
            $data['end_time'],
            $data['notes'],
            $id
        ]);
    }

    public static function setContractPath(int $id, string $path): void {
        $st = DB::pdo()->prepare("UPDATE bookings SET contract_path=?, updated_at=NOW() WHERE id=?");
        $st->execute([$path, $id]);
    }
}
