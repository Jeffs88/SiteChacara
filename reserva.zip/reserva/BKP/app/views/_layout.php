<?php $u = current_user(); ?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= h($title ?? 'Reserva') ?> | Espaço Recanto Verde</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">
  <style>
    .topbar {display:flex; gap:12px; align-items:center; justify-content:space-between;}
    .muted{opacity:.75}
    .tag{display:inline-block;padding:2px 8px;border:1px solid #ddd;border-radius:999px;font-size:12px}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    .grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
    @media (max-width: 900px){ .grid,.grid3{grid-template-columns:1fr} }
    .btnrow{display:flex; gap:10px; flex-wrap:wrap}
    .danger{border-color:#c00;color:#c00}
    .ok{border-color:#0a0;color:#0a0}
    table td, table th{vertical-align:top}
  </style>
  <?= $head ?? '' ?>
</head>
<body>
  <div class="topbar">
    <div>
      <strong>Espaço Recanto Verde</strong><br>
      <span class="muted">Sistema de Reservas</span>
    </div>
    <div class="btnrow">
      <a href="<?= BASE_URL ?>/disponibilidade">Disponibilidade</a>
      <a href="<?= BASE_URL ?>/reservar">Reservar</a>
      <a href="<?= BASE_URL ?>/precos">Preços</a>
      <?php if ($u): ?>
        <?php if ($u['role']==='ADMIN'): ?>
          <a href="<?= BASE_URL ?>/admin">Admin</a>
        <?php else: ?>
          <a href="<?= BASE_URL ?>/caseiro">Caseiro</a>
        <?php endif; ?>
        <a href="<?= BASE_URL ?>/perfil">Meu perfil</a>
        <a class="danger" href="<?= BASE_URL ?>/logout">Sair</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/login">Login</a>
      <?php endif; ?>
    </div>
  </div>

  <?php if (!empty($flash)): ?>
    <p class="tag"><?= h($flash) ?></p>
  <?php endif; ?>

  <?= $content ?? '' ?>

  <hr>
  <p class="muted">© <?= date('Y') ?> Espaço Recanto Verde</p>
</body>
</html>
