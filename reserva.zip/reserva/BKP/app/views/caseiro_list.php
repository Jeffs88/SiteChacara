<h1>Painel do Caseiro</h1>
<p class="muted">Aqui aparecem apenas locações confirmadas (sem valores).</p>

<table>
  <thead>
    <tr>
      <th>Data</th>
      <th>Nome</th>
      <th>Horário</th>
      <th>Pago?</th>
      <th>Itens adicionais</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($list as $b): ?>
    <tr>
      <td><?= h(date('d/m/Y', strtotime($b['date']))) ?></td>
      <td><?= h($b['client_name']) ?></td>
      <td>08:00 – <?= h(substr($b['end_time'],0,5)) ?></td>
      <td><?= h($b['paid_status'] ?? 'NAO') ?></td>
      <td><?= nl2br(h($b['additional_items'] ?? '')) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
