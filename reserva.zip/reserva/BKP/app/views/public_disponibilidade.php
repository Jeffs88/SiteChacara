<h1>Disponibilidade</h1>
<p class="muted">Mostra apenas datas reservadas/pendentes. Para reservar, vá em <a href="<?= BASE_URL ?>/reservar">Reservar</a>.</p>

<div class="grid">
  <form method="get" action="<?= BASE_URL ?>/disponibilidade">
    <label>Início</label>
    <input type="date" name="start" value="<?= h($start) ?>">
    <label>Fim</label>
    <input type="date" name="end" value="<?= h($end) ?>">
    <button type="submit">Filtrar</button>
  </form>

  <div>
    <h3>Legenda</h3>
    <p><span class="tag ok">CONFIRMADA</span> <span class="tag">PENDENTE</span></p>
  </div>
</div>

<table>
  <thead>
    <tr>
      <th>Data</th>
      <th>Status</th>
      <th>Horário</th>
      <th>Pessoas</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($bookings as $b): ?>
    <tr>
      <td><?= h(date('d/m/Y', strtotime($b['date']))) ?></td>
      <td>
        <?php if ($b['status']==='CONFIRMED'): ?>
          <span class="tag ok">CONFIRMADA</span>
        <?php else: ?>
          <span class="tag">PENDENTE</span>
        <?php endif; ?>
      </td>
      <td>08:00 – <?= h(substr($b['end_time'],0,5)) ?></td>
      <td><?= h((string)$b['people']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<p class="muted">Se a data não aparece aqui, ela está disponível (ainda assim confirmamos antes).</p>
