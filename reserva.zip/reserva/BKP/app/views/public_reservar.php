<h1>Reserva</h1>
<p class="muted">Preencha para solicitar a pré-reserva. Depois você recebe o contrato para assinatura.</p>

<form method="post" action="<?= BASE_URL ?>/reservar" enctype="multipart/form-data">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">

  <div class="grid">
    <div>
      <label>Data do evento</label>
      <input type="date" name="date" required>
    </div>
    <div>
      <label>Quantidade de pessoas (crianças acima de 2 anos contam)</label>
      <select name="people" required>
        <option value="">Selecione</option>
        <option value="50">Até 50</option>
        <option value="100">Até 100</option>
        <option value="150">Até 150</option>
        <option value="200">Até 200</option>
        <option value="250">Até 250</option>
        <option value="251">Mais de 250</option>
      </select>
    </div>
  </div>

  <label>Horário limite de término</label>
  <select name="end_hour" required>
    <option value="18">18:00</option>
    <option value="19">19:00</option>
    <option value="20">20:00</option>
    <option value="21">21:00</option>
    <option value="22">22:00</option>
  </select>

  <div class="grid">
    <div>
      <label>Nome completo</label>
      <input name="client_name" required>
    </div>
    <div>
      <label>Email</label>
      <input name="client_email" type="email" required>
    </div>
  </div>

  <label>WhatsApp/Telefone</label>
  <input name="client_phone" required>

  <label>Itens adicionais / observações</label>
  <textarea name="additional_items" rows="3" placeholder="Ex.: mesa extra, decoração, som, etc."></textarea>

  <label>Documento pessoal (foto/arquivo)</label>
  <input type="file" name="document" accept=".jpg,.jpeg,.png,.pdf" required>

  <button type="submit">Enviar pré-reserva</button>
</form>

<p class="muted">Ao enviar, você concorda com o envio dos dados para elaboração do contrato.</p>
