<?php
require __DIR__ . '/config/config.php';
require __DIR__ . '/app/lib/Logger.php';
require __DIR__ . '/app/lib/DB.php';
require __DIR__ . '/app/lib/Helpers.php';

require __DIR__ . '/app/models/User.php';
require __DIR__ . '/app/models/Booking.php';
require __DIR__ . '/app/models/Pricing.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// remove base path (/reserva) if present
$basePath = parse_url(BASE_URL, PHP_URL_PATH) ?: '';
if ($basePath && str_starts_with($path, $basePath)) {
    $path = substr($path, strlen($basePath));
}
$path = '/' . trim($path, '/');

function render(string $view, array $vars = []): void {
    extract($vars);
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    ob_start();
    require __DIR__ . '/app/views/' . $view . '.php';
    $content = ob_get_clean();
    $title = $vars['title'] ?? 'Reserva';
    require __DIR__ . '/app/views/_layout.php';
}

function set_flash(string $msg): void {
    $_SESSION['flash'] = $msg;
}

try {
    switch ($path) {
        case '/':
        case '/disponibilidade':
            // show calendar availability
            $start = $_GET['start'] ?? date('Y-m-01');
            $end = $_GET['end'] ?? date('Y-m-t');
            $bookings = Booking::listBetween($start, $end);
            render('public_disponibilidade', [
                'title' => 'Disponibilidade',
                'bookings' => $bookings,
                'start' => $start,
                'end' => $end,
            ]);
            break;

        case '/precos':
            render('public_precos', ['title' => 'Preços']);
            break;

        case '/reservar':
            if (is_post()) {
                csrf_check();
                $date = $_POST['date'] ?? '';
                $people = (int)($_POST['people'] ?? 0);
                $endHour = (int)($_POST['end_hour'] ?? 18);
                $name = trim($_POST['client_name'] ?? '');
                $email = trim($_POST['client_email'] ?? '');
                $phone = trim($_POST['client_phone'] ?? '');
                $items = trim($_POST['additional_items'] ?? '');

                if (!$date || !$name || !$email || !$phone || $people < 1) {
                    set_flash('Preencha todos os campos obrigatórios.');
                    redirect('/reservar');
                }
                if ($endHour < 18 || $endHour > 22) $endHour = 18;

                $month = (int)date('n', strtotime($date));
                $calc = Pricing::calculate($month, $people, $endHour);

                $docPath = upload_file($_FILES['document'] ?? [], 'docs');
                if (!$docPath) {
                    set_flash('Falha ao enviar o documento. Tente novamente.');
                    redirect('/reservar');
                }

                $id = Booking::createPre([
                    'date' => $date,
                    'end_hour' => $endHour,
                    'people' => $people,
                    'client_name' => $name,
                    'client_email' => $email,
                    'client_phone' => $phone,
                    'additional_items' => $items,
                    'suggested_total' => $calc['total_suggested'],
                    'document_path' => $docPath,
                ]);

                set_flash('Pré-reserva enviada! Em breve confirmaremos pelo WhatsApp/Email.');
                redirect('/reserva-enviada?id=' . $id);
            } else {
                render('public_reservar', ['title' => 'Reservar']);
            }
            break;

        case '/reserva-enviada':
            $id = (int)($_GET['id'] ?? 0);
            $b = $id ? Booking::find($id) : null;
            render('public_reserva_enviada', ['title' => 'Reserva enviada', 'b' => $b]);
            break;

        case '/login':
            if (is_post()) {
                csrf_check();
                $email = trim($_POST['email'] ?? '');
                $pass = $_POST['password'] ?? '';
                $u = User::findByEmail($email);
                if ($u && password_verify($pass, $u['password_hash'])) {
                    $_SESSION['user'] = ['id'=>$u['id'], 'name'=>$u['name'], 'email'=>$u['email'], 'role'=>$u['role']];
                    set_flash('Bem-vindo!');
                    redirect($u['role']==='ADMIN' ? '/admin' : '/caseiro');
                }
                set_flash('Login inválido.');
                redirect('/login');
            } else {
                render('auth_login', ['title' => 'Login']);
            }
            break;

        case '/logout':
            session_destroy();
            redirect('/login');
            break;

        case '/perfil':
            require_login();
            if (is_post()) {
                csrf_check();
                $new = $_POST['new_password'] ?? '';
                if (strlen($new) < 8) {
                    set_flash('Senha muito curta (mínimo 8).');
                    redirect('/perfil');
                }
                $hash = password_hash($new, PASSWORD_DEFAULT);
                User::updatePassword((int)current_user()['id'], $hash);
                set_flash('Senha alterada.');
                redirect('/perfil');
            } else {
                render('auth_perfil', ['title'=>'Meu perfil']);
            }
            break;

        case '/admin':
            require_login(); require_role('ADMIN');
            $list = Booking::listAll(250);
            render('admin_list', ['title'=>'Admin', 'list'=>$list]);
            break;

        case '/admin/booking':
            require_login(); require_role('ADMIN');
            $id = (int)($_GET['id'] ?? 0);
            $b = $id ? Booking::find($id) : null;
            if (!$b) { set_flash('Reserva não encontrada.'); redirect('/admin'); }

            if (is_post()) {
                csrf_check();
                $status = $_POST['status'] ?? 'PENDING';
                $total = (int)($_POST['total_price'] ?? 0);
                $entry = (int)($_POST['entry_paid'] ?? 0);
                $remaining = max(0, $total - $entry);
                $paidStatus = $_POST['paid_status'] ?? 'NAO';
                $items = trim($_POST['additional_items'] ?? '');
                $endTime = $_POST['end_time'] ?? $b['end_time'];
                $notes = trim($_POST['notes'] ?? '');

                Booking::updateAdmin($id, [
                    'status' => $status,
                    'total_price' => $total,
                    'entry_paid' => $entry,
                    'remaining' => $remaining,
                    'paid_status' => $paidStatus,
                    'additional_items' => $items,
                    'end_time' => $endTime,
                    'notes' => $notes,
                ]);

                // gerar contrato (HTML)
                if (isset($_POST['generate_contract'])) {
                    $b2 = Booking::find($id);
                    $contractHtml = file_get_contents(__DIR__ . '/app/templates/contract.html');
                    $replace = [
                        '{{CLIENT_NAME}}' => $b2['client_name'],
                        '{{CLIENT_EMAIL}}' => $b2['client_email'],
                        '{{CLIENT_PHONE}}' => $b2['client_phone'],
                        '{{DATE}}' => date('d/m/Y', strtotime($b2['date'])),
                        '{{START}}' => '08:00',
                        '{{END}}' => substr($b2['end_time'],0,5),
                        '{{PEOPLE}}' => (string)$b2['people'],
                        '{{TOTAL}}' => 'R$ ' . number_format((int)$b2['total_price'], 2, ',', '.'),
                        '{{ENTRY}}' => 'R$ ' . number_format((int)$b2['entry_paid'], 2, ',', '.'),
                        '{{REMAINING}}' => 'R$ ' . number_format((int)$b2['remaining'], 2, ',', '.'),
                        '{{ITEMS}}' => nl2br(h($b2['additional_items'] ?? '')),
                        '{{TODAY}}' => date('d/m/Y'),
                    ];
                    $out = strtr($contractHtml, $replace);
                    if (!is_dir(CONTRACT_PATH)) @mkdir(CONTRACT_PATH, 0775, true);
                    $fname = 'contrato_reserva_' . $id . '.html';
                    file_put_contents(CONTRACT_PATH . '/' . $fname, $out);
                    Booking::setContractPath($id, 'contracts/' . $fname);
                    set_flash('Contrato gerado.');
                }

                set_flash('Reserva atualizada.');
                redirect('/admin/booking?id=' . $id);
            } else {
                render('admin_booking', ['title'=>'Reserva #' . $id, 'b'=>$b]);
            }
            break;

        case '/admin/precos':
            require_login(); require_role('ADMIN');
            if (is_post()) {
                csrf_check();
                $monthFrom = (int)($_POST['month_from'] ?? 11);
                $monthTo = (int)($_POST['month_to'] ?? 12);
                $peopleMax = (int)($_POST['people_max'] ?? 50);
                $base = (int)($_POST['base_price'] ?? 0);
                $extra = (int)($_POST['extra_hour_price'] ?? 0);

                $st = DB::pdo()->prepare("INSERT INTO price_rules (month_from, month_to, people_max, base_price, extra_hour_price) VALUES (?,?,?,?,?)");
                $st->execute([$monthFrom,$monthTo,$peopleMax,$base,$extra]);
                set_flash('Regra adicionada.');
                redirect('/admin/precos');
            } else {
                $rules = Pricing::getRules();
                render('admin_precos', ['title'=>'Configurar preços', 'rules'=>$rules]);
            }
            break;

        case '/admin/besign':
            require_login(); require_role('ADMIN');
            $id = (int)($_GET['id'] ?? 0);
            $b = $id ? Booking::find($id) : null;
            if (!$b || empty($b['contract_path'])) { set_flash('Gere o contrato antes.'); redirect('/admin/booking?id='.$id); }
            if (!BESIGN_ENABLED) { set_flash('BeSign desabilitado no config.'); redirect('/admin/booking?id='.$id); }

            // Aqui seria a chamada real para a API da BeSign com TOKEN e endpoint.
            // Como cada conta tem credenciais/detalhes, deixei como "stub" para você colar.
            // Ex.: enviar documento, definir assinantes, retornar link.
            Logger::info("Stub BeSign: enviar contrato da reserva {$id} path={$b['contract_path']}");
            set_flash('Stub BeSign: integração ainda precisa das suas credenciais/endpoint.');
            redirect('/admin/booking?id='.$id);
            break;

        case '/caseiro':
            require_login(); require_role('CARETAKER');
            $list = Booking::listConfirmedUpcoming();
            render('caseiro_list', ['title'=>'Painel do Caseiro', 'list'=>$list]);
            break;

        default:
            http_response_code(404);
            echo "Página não encontrada.";
    }
} catch (Throwable $e) {
    Logger::error($e->getMessage() . " | " . $e->getFile() . ":" . $e->getLine());
    http_response_code(500);
    echo "Erro interno. Verifique storage/logs/app.log";
}
