<?php
require __DIR__ . '/config/config.php';
require __DIR__ . '/app/lib/DB.php';
require __DIR__ . '/app/lib/Helpers.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_login();
require_role('ADMIN');

$p = $_GET['p'] ?? '';
$p = str_replace(['..','\\'], '', $p);

$full = STORAGE_PATH . '/' . $p;
if (!is_file($full)) { http_response_code(404); echo "Arquivo não encontrado."; exit; }

$ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
$mime = 'text/plain';
if ($ext === 'html') $mime = 'text/html; charset=utf-8';
if ($ext === 'pdf') $mime = 'application/pdf';

header('Content-Type: ' . $mime);
readfile($full);
