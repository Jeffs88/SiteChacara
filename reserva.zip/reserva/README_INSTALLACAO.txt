SISTEMA DE RESERVAS – ESPAÇO RECANTO VERDE (v1)
================================================

✅ Feito para hospedagem compartilhada (HostGator) com PHP 8+ e MySQL.
✅ Instala em subpasta: /reserva
✅ Perfis: ADMIN (vê tudo) e CASEIRO (não vê valores).
✅ Público: calendário de disponibilidade + formulário de pré-reserva.
✅ Gera contrato em HTML (pronto para imprimir ou assinar).
✅ Integração BeSign: deixei um ponto de integração (config + botão), mas você precisa colocar suas chaves/endpoint.

------------------------------------------------
1) REQUISITOS NA HOSPEDAGEM
------------------------------------------------
- PHP 8.0+ (PDO MySQL habilitado)
- MySQL/MariaDB
- Apache com .htaccess habilitado

------------------------------------------------
2) UPLOAD
------------------------------------------------
Faça upload de TODA a pasta "reserva" para:
public_html/reserva

A estrutura deve ficar:
public_html/reserva/index.php
public_html/reserva/.htaccess
public_html/reserva/app/...
public_html/reserva/storage/...

------------------------------------------------
3) CRIAR BANCO E TABELAS
------------------------------------------------
1) Crie um banco MySQL no cPanel (ex: recanto_reserva).
2) Abra o phpMyAdmin e rode o arquivo:
   database/schema.sql

------------------------------------------------
4) CONFIGURAR ACESSO AO BANCO
------------------------------------------------
Edite o arquivo:
config/config.php

Preencha:
DB_HOST, DB_NAME, DB_USER, DB_PASS
e ajuste BASE_URL (ex: https://www.espacorecantoverde.com.br/reserva)

------------------------------------------------
5) PRIMEIRO LOGIN
------------------------------------------------
Usuário admin padrão:
- email: admin@recantoverde.local
- senha: Admin@12345

⚠️ ENTRE E TROQUE A SENHA NO MENU: "Meu Perfil"

Usuário caseiro padrão:
- email: caseiro@recantoverde.local
- senha: Caseiro@12345

------------------------------------------------
6) COMO FUNCIONA (RESUMO)
------------------------------------------------
- Página pública:
  /reserva/disponibilidade  -> mostra dias disponíveis e reservados (sem valores)
  /reserva/reservar         -> cliente preenche dados, escolhe pessoas e horário final, envia documento
  /reserva/precos           -> tabela de referência

- Área administrativa:
  /reserva/login
  Admin:
    - Aprovar/recusar pré-reserva
    - Definir valores (entrada, total, itens adicionais)
    - Marcar "pago" (ou "parcial")
    - Gerar contrato (HTML) com dados
    - Botão "Enviar para BeSign" (precisa configurar)
  Caseiro:
    - Vê apenas reservas confirmadas:
      data, nome, pago? (sim/não), itens adicionais, horário término

------------------------------------------------
7) PRECIFICAÇÃO IMPLEMENTADA (JAN–OUT)
------------------------------------------------
Base (08:00–18:00):
- até 50 pessoas: 1200
  hora extra: 125/h (até 22:00)
- 51–100 pessoas: 1600
  hora extra: 135/h
- 101–200 pessoas: 2000
  hora extra: 150/h
- acima de 200: por enquanto usa o mesmo de 200 (você ajusta em "Configurações/Preços")

Novembro/Dezembro:
- Está preparado para você cadastrar na tela "Configurações/Preços"
  (valores diferentes por mês)

✅ Crianças acima de 2 anos contam na quantidade.

------------------------------------------------
8) SEGURANÇA E BOAS PRÁTICAS
------------------------------------------------
- Troque as senhas padrão imediatamente.
- Em produção, garanta HTTPS no domínio.
- Pasta storage possui arquivos enviados/contratos; mantenha protegida via .htaccess.

------------------------------------------------
9) SUPORTE (O QUE VOCÊ ME MANDA SE DER ERRO)
------------------------------------------------
- Versão do PHP no HostGator
- Print/erro do Apache (error_log) e do arquivo storage/logs/app.log
- Seu config/config.php (sem senha) ou só as variáveis relevantes

