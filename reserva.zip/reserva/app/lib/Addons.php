<?php
class Addons {
    public static function catalog(): array {
        return [
            'mesa_4cadeiras' => ['label' => 'Jogo de 1 mesa e 4 cadeiras', 'price' => 20],
            'inflaveis' => ['label' => 'Brinquedos Infláveis', 'price' => 80],
            'chopeira' => ['label' => 'Chopeira', 'price' => 30],
            'banda' => ['label' => 'Banda', 'price' => 100],
        ];
    }

    public static function normalize(array $qtyByKey, string $otherText): array {
        $cat = self::catalog();
        $items = [];
        foreach ($cat as $k => $v) {
            $q = (int)($qtyByKey[$k] ?? 0);
            if ($q > 0) {
                $items[] = [
                    'key' => $k,
                    'label' => $v['label'],
                    'qty' => $q,
                    'unit_price' => (int)$v['price'],
                    'total' => (int)$v['price'] * $q,
                ];
            }
        }
        $otherText = trim($otherText);
        $addonsTotal = 0;
        foreach ($items as $i) $addonsTotal += (int)$i['total'];

        return [
            'items' => $items,
            'other' => $otherText,
            'addons_total' => $addonsTotal,
        ];
    }

    public static function prettyText(?string $addonsJson, ?string $fallbackAdditionalItems): string {
        if ($addonsJson) {
            $d = json_decode($addonsJson, true);
            if (is_array($d) && isset($d['items']) && is_array($d['items'])) {
                $parts = [];
                foreach ($d['items'] as $i) {
                    $parts[] = ((int)$i['qty']) . 'x ' . ($i['label'] ?? '') . ' (R$ ' . number_format((int)($i['unit_price'] ?? 0),2,',','.') . ')';
                }
                if (!empty($d['other'])) $parts[] = 'Outros: ' . $d['other'];
                return implode("; ", $parts);
            }
        }
        return trim((string)$fallbackAdditionalItems);
    }
}
