<?php
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function redirect(string $path): void {
    header('Location: ' . BASE_URL . $path);
    exit;
}

function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }

function csrf_token(): string {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}

function csrf_check(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    $t = $_POST['csrf'] ?? '';
    if (!$t || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        http_response_code(400);
        echo "CSRF inválido.";
        exit;
    }
}

function current_user(): ?array {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!current_user()) redirect('/login');
}

function require_role(string $role): void {
    $u = current_user();
    if (!$u || ($u['role'] ?? '') !== $role) {
        http_response_code(403);
        echo "Acesso negado.";
        exit;
    }
}

function role_in(array $roles): bool {
    $u = current_user();
    return $u && in_array(($u['role'] ?? ''), $roles, true);
}

function upload_file(array $file, string $subdir): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    $ext = pathinfo($file['name'] ?? '', PATHINFO_EXTENSION);
    $safe = bin2hex(random_bytes(10)) . ($ext ? ('.' . strtolower($ext)) : '');
    $dir = UPLOAD_PATH . '/' . $subdir;
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $dest = $dir . '/' . $safe;
    if (!move_uploaded_file($file['tmp_name'], $dest)) return null;
    return $subdir . '/' . $safe;
}
