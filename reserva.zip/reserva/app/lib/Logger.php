<?php
class Logger {
    public static function info(string $msg): void {
        self::write('INFO', $msg);
    }
    public static function error(string $msg): void {
        self::write('ERROR', $msg);
    }
    private static function write(string $level, string $msg): void {
        $line = date('c') . " [$level] " . $msg . PHP_EOL;
        $file = LOG_PATH . '/app.log';
        @file_put_contents($file, $line, FILE_APPEND);
    }
}
