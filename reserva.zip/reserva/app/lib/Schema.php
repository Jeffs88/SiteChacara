<?php
class Schema {
    public static function ensure(): void {
        $pdo = DB::pdo();
        $dbName = DB_NAME;

        $need = [
            'client_cpf' => "ALTER TABLE bookings ADD COLUMN client_cpf VARCHAR(30) NULL AFTER client_name",
            'client_rg' => "ALTER TABLE bookings ADD COLUMN client_rg VARCHAR(30) NULL AFTER client_cpf",
            'client_address' => "ALTER TABLE bookings ADD COLUMN client_address VARCHAR(255) NULL AFTER client_rg",
            'addons_json' => "ALTER TABLE bookings ADD COLUMN addons_json TEXT NULL AFTER additional_items",
            'type_event' => "ALTER TABLE bookings ADD COLUMN type_event VARCHAR(80) NULL AFTER client_phone",
            'notes' => "ALTER TABLE bookings ADD COLUMN notes TEXT NULL AFTER type_event"
        ];

        foreach ($need as $col => $sql) {
            if (!self::columnExists($pdo, $dbName, 'bookings', $col)) {
                $pdo->exec($sql);
            }
        }
    }

    private static function columnExists(PDO $pdo, string $db, string $table, string $col): bool {
        $st = $pdo->prepare("SELECT COUNT(*) c FROM INFORMATION_SCHEMA.COLUMNS
                             WHERE TABLE_SCHEMA=? AND TABLE_NAME=? AND COLUMN_NAME=?");
        $st->execute([$db, $table, $col]);
        $r = $st->fetch();
        return ((int)($r['c'] ?? 0)) > 0;
    }
}
