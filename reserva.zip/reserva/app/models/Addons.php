<?php
class Addons {
    public static function catalog(): array {
        return [
            'mesa_cadeiras' => ['label' => 'Jogo de 1 mesa e 4 cadeiras', 'price' => 20],
            'inflaveis'     => ['label' => 'Brinquedos Infláveis',        'price' => 80],
            'chopeira'      => ['label' => 'Chopeira',                    'price' => 30],
            'banda'         => ['label' => 'Banda',                       'price' => 100],
        ];
    }

    public static function normalize(array $qtyMap, string $otherText): array {
        $cat = self::catalog();
        $items = [];
        $total = 0;

        foreach ($cat as $k => $a) {
            $q = isset($qtyMap[$k]) ? (int)$qtyMap[$k] : 0;
            if ($q > 0) {
                $items[] = ['key'=>$k,'label'=>$a['label'],'qty'=>$q,'unit'=>$a['price'],'subtotal'=>$q*$a['price']];
                $total += $q*$a['price'];
            }
        }

        $otherText = trim($otherText);
        if ($otherText !== '') {
            $items[] = ['key'=>'other','label'=>'Outros','qty'=>1,'unit'=>0,'subtotal'=>0,'desc'=>$otherText];
        }

        return ['items'=>$items,'addons_total'=>$total,'other_text'=>$otherText];
    }

    public static function prettyText(?string $addonsJson, ?string $fallbackAdditionalItems): string {
        if ($addonsJson) {
            $d = json_decode($addonsJson, true);
            if (is_array($d) && isset($d['items']) && is_array($d['items'])) {
                $parts = [];
                foreach ($d['items'] as $it) {
                    if (($it['key'] ?? '') === 'other') {
                        $parts[] = 'Outros: ' . ($it['desc'] ?? '');
                    } else {
                        $parts[] = ($it['label'] ?? '') . ' x' . (int)($it['qty'] ?? 0);
                    }
                }
                return implode(' | ', array_filter($parts));
            }
        }
        return (string)($fallbackAdditionalItems ?? '');
    }
}
