<?php
class Booking {

    private static function hasClientIdColumn(): bool {
        try {
            $pdo = DB::pdo();
            $st = $pdo->prepare("SELECT COUNT(*) c
              FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'bookings' AND COLUMN_NAME = 'client_id'");
            $st->execute([DB_NAME]);
            $row = $st->fetch(PDO::FETCH_ASSOC);
            return ((int)($row['c'] ?? 0)) > 0;
        } catch (Throwable $e) {
            return false;
        }
    }

    public static function createPre(array $data): int {
        $pdo = DB::pdo();

        $hasClientId = self::hasClientIdColumn();
        $cols = [
            'status' => 'PENDING',
            'date' => $data['date'],
            'start_time' => '08:00:00',
            'end_time' => sprintf('%02d:00:00', (int)$data['end_hour']),
            'people' => (int)$data['people'],
            'kids_over2_counted' => 1,
            'client_name' => $data['client_name'],
            'client_cpf' => $data['client_cpf'],
            'client_rg' => $data['client_rg'] ?? '',
            'client_address' => $data['client_address'],
            'client_email' => $data['client_email'],
            'client_phone' => $data['client_phone'],
            'type_event' => $data['type_event'] ?? '',
            'notes' => $data['notes'] ?? '',
            'additional_items' => $data['additional_items'] ?? '',
            'addons_json' => $data['addons_json'] ?? null,
            'suggested_total' => (int)$data['suggested_total'],
            'document_path' => $data['document_path'],
        ];

        if ($hasClientId) {
            $cols = ['client_id' => (int)($data['client_id'] ?? 0)] + $cols;
        }

        // Build SQL with named params to avoid placeholder mismatch
        $fields = array_keys($cols);
        $placeholders = array_map(fn($k) => ':' . $k, $fields);

        $sql = "INSERT INTO bookings (" . implode(',', $fields) . ",created_at) VALUES (" .
               implode(',', $placeholders) . ",NOW())";

        $st = $pdo->prepare($sql);

        foreach ($cols as $k => $v) {
            $st->bindValue(':' . $k, $v);
        }

        $st->execute();
        return (int)$pdo->lastInsertId();
    }

    public static function listBetween(string $start, string $end): array {
        $st = DB::pdo()->prepare("SELECT * FROM bookings WHERE date BETWEEN ? AND ? AND status IN ('PENDING','CONFIRMED') ORDER BY date ASC");
        $st->execute([$start, $end]);
        return $st->fetchAll() ?: [];
    }

    public static function listConfirmedUpcoming(): array {
        $st = DB::pdo()->query("SELECT * FROM bookings WHERE status='CONFIRMED' AND date >= CURDATE() ORDER BY date ASC");
        return $st->fetchAll() ?: [];
    }

    public static function listAll(int $limit=200): array {
        $st = DB::pdo()->prepare("SELECT * FROM bookings ORDER BY created_at DESC LIMIT ?");
        $st->bindValue(1, $limit, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll() ?: [];
    }

    public static function find(int $id): ?array {
        $st = DB::pdo()->prepare("SELECT * FROM bookings WHERE id=?");
        $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }

    public static function updateStatus(int $id, string $status): void {
        $st = DB::pdo()->prepare("UPDATE bookings SET status=? WHERE id=?");
        $st->execute([$status, $id]);
    }

    public static function delete(int $id): void {
        $st = DB::pdo()->prepare("DELETE FROM bookings WHERE id=?");
        $st->execute([$id]);
    }

    public static function statusMapForMonth(int $year, int $month): array {
        $start = sprintf('%04d-%02d-01', $year, $month);
        $end = date('Y-m-t', strtotime($start));
        $rows = self::listBetween($start, $end);
        $map = [];
        foreach ($rows as $r) {
            $map[$r['date']] = $r['status'];
        }
        return $map;
    }
}
