<?php
class Client {
    public static function findByEmail(string $email): ?array {
        $st = DB::pdo()->prepare("SELECT * FROM clients WHERE email=? LIMIT 1");
        $st->execute([$email]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }
    public static function find(int $id): ?array {
        $st = DB::pdo()->prepare("SELECT * FROM clients WHERE id=? LIMIT 1");
        $st->execute([$id]);
        $r = $st->fetch(PDO::FETCH_ASSOC);
        return $r ?: null;
    }
    public static function create(array $d): int {
        $st = DB::pdo()->prepare("INSERT INTO clients (name,email,phone,password_hash,created_at) VALUES (?,?,?,?,NOW())");
        $st->execute([$d['name'],$d['email'],$d['phone'],$d['password_hash']]);
        return (int)DB::pdo()->lastInsertId();
    }
}
