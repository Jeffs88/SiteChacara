<?php
class Pricing {
    // Busca regras do banco (permite configurar Nov/Dez e outros ajustes)
    public static function getRules(): array {
        $st = DB::pdo()->query("SELECT * FROM price_rules ORDER BY month_from, people_max");
        return $st->fetchAll() ?: [];
    }

    public static function calculate(int $month, int $people, int $endHour): array {
        // endHour: 18..22 (limite)
        $baseStart = 8;
        $baseEnd = 18;

        $extraHours = max(0, min(22, $endHour) - $baseEnd);

        // Regra padrão Jan-Out (1-10) – conforme você passou
        $default = [
            ['maxPeople' => 50,  'base' => 1200, 'extra' => 125],
            ['maxPeople' => 100, 'base' => 1600, 'extra' => 135],
            ['maxPeople' => 200, 'base' => 2000, 'extra' => 150],
        ];

        // Primeiro tenta pegar regra no banco para o mês
        $rules = self::getRules();
        $candidates = [];
        foreach ($rules as $r) {
            if ($month >= (int)$r['month_from'] && $month <= (int)$r['month_to']) {
                $candidates[] = $r;
            }
        }

        $picked = null;
        if ($candidates) {
            // escolhe a menor faixa que comporte as pessoas
            usort($candidates, fn($a,$b) => (int)$a['people_max'] <=> (int)$b['people_max']);
            foreach ($candidates as $r) {
                if ($people <= (int)$r['people_max']) { $picked = $r; break; }
            }
            if (!$picked) $picked = end($candidates);
        } else {
            // fallback padrão: mês 1-10 usa default, 11-12 também, mas você deve configurar no banco
            foreach ($default as $d) {
                if ($people <= $d['maxPeople']) { $picked = $d; break; }
            }
            if (!$picked) $picked = end($default);
        }

        $base = (int)($picked['base_price'] ?? $picked['base'] ?? 0);
        $extraRate = (int)($picked['extra_hour_price'] ?? $picked['extra'] ?? 0);

        $total = $base + ($extraHours * $extraRate);

        return [
            'base_price' => $base,
            'extra_hours' => $extraHours,
            'extra_rate' => $extraRate,
            'total_suggested' => $total,
        ];
    }
}
