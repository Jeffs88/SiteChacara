<?php
class User {
    public static function findByEmail(string $email): ?array {
        $st = DB::pdo()->prepare("SELECT id, name, email, password_hash, role FROM users WHERE email = ?");
        $st->execute([$email]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public static function findById(int $id): ?array {
        $st = DB::pdo()->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ?: null;
    }

    public static function updatePassword(int $id, string $newHash): void {
        $st = DB::pdo()->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        $st->execute([$newHash, $id]);
    }
}
