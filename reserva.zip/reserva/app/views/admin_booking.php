<h1>Reserva #<?= h((string)$b['id']) ?></h1>

<div class="grid">
  <div>
    <h3>Reserva</h3>
<p>
  <strong>Nome:</strong> <?= h($b['client_name']) ?><br>
  <strong>Data:</strong> <?= h(date('d/m/Y', strtotime($b['date']))) ?><br>
  <strong>Horário:</strong> 08:00 – <?= h(substr($b['end_time'],0,5)) ?><br>
  <strong>Pessoas:</strong> <?= h((string)$b['people']) ?>
</p>
    <p><strong>Itens adicionais:</strong><br><?= nl2br(h($b['additional_items'] ?? '')) ?></p>
    <p class="muted">Documento enviado: <?= h($b['document_path'] ?? '-') ?></p>
  </div>

  <div>
    <h3>Administração</h3>
    <form method="post" action="<?= BASE_URL ?>/admin/booking?id=<?= (int)$b['id'] ?>">
      <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">

      <label>Status</label>
      <select name="status">
        <option value="PENDING" <?= $b['status']==='PENDING'?'selected':'' ?>>PENDING</option>
        <option value="CONFIRMED" <?= $b['status']==='CONFIRMED'?'selected':'' ?>>CONFIRMED</option>
        <option value="CANCELLED" <?= $b['status']==='CANCELLED'?'selected':'' ?>>CANCELLED</option>
      </select>

      <div class="grid3">
        <div>
          <label>Valor total (R$)</label>
          <input type="number" name="total_price" value="<?= h((string)($b['total_price'] ?? $b['suggested_total'])) ?>">
        </div>
        <div>
          <label>Entrada paga (R$)</label>
          <input type="number" name="entry_paid" value="<?= h((string)($b['entry_paid'] ?? 0)) ?>">
        </div>
        <div>
          <label>Pago?</label>
          <select name="paid_status">
            <?php $ps = $b['paid_status'] ?? 'NAO'; ?>
            <option value="NAO" <?= $ps==='NAO'?'selected':'' ?>>NÃO</option>
            <option value="PARCIAL" <?= $ps==='PARCIAL'?'selected':'' ?>>PARCIAL</option>
            <option value="SIM" <?= $ps==='SIM'?'selected':'' ?>>SIM</option>
          </select>
        </div>
      </div>

      <label>Horário término</label>
      <select name="end_time">
        <?php $eh = substr($b['end_time'],0,2); ?>
        <?php foreach ([18,19,20,21,22] as $h): ?>
          <option value="<?= sprintf('%02d:00:00',$h) ?>" <?= ((int)$eh===$h)?'selected':'' ?>><?= sprintf('%02d:00',$h) ?></option>
        <?php endforeach; ?>
      </select>

      <label>Itens adicionais (para o caseiro ver)</label>
      <textarea name="additional_items" rows="3"><?= h($b['additional_items'] ?? '') ?></textarea>

      <label>Notas internas</label>
      <textarea name="notes" rows="3"><?= h($b['notes'] ?? '') ?></textarea>

      <div class="btnrow">
        <button type="submit">Salvar</button>
        <button type="submit" name="generate_contract" value="1">Gerar/Atualizar contrato</button>
        <?php if (!empty($b['contract_path'])): ?>
          <a class="tag" href="<?= BASE_URL ?>/storage_view.php?p=<?= urlencode($b['contract_path']) ?>" target="_blank">Ver contrato</a>
          <a class="tag" href="<?= BASE_URL ?>/admin/besign?id=<?= (int)$b['id'] ?>">Enviar para BeSign</a>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>
