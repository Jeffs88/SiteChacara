<h1>Painel Admin</h1>
<p class="btnrow">
  <a class="tag" href="<?= BASE_URL ?>/admin/precos">Configurações de preços</a>
</p>

<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Data</th>
      <th>Cliente</th>
      <th>Status</th>
      <th>Total</th>
      <th>Pago?</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($list as $b): ?>
      <tr>
        <td>#<?= h((string)$b['id']) ?></td>
        <td><?= h(date('d/m/Y', strtotime($b['date']))) ?></td>
        <td><?= h($b['client_name']) ?></td>
        <td><?= h($b['status']) ?></td>
        <td><?= $b['total_price'] !== null ? ('R$ '.number_format((int)$b['total_price'],2,',','.')) : '<span class="muted">sugerido: R$ '.number_format((int)$b['suggested_total'],2,',','.').'</span>' ?></td>
        <td><?= h($b['paid_status'] ?? '-') ?></td>
        <td><a href="<?= BASE_URL ?>/admin/booking?id=<?= (int)$b['id'] ?>">Abrir</a></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>
