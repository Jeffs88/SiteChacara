<h1>Configurar preços</h1>
<p class="muted">Use isso para cadastrar valores de Novembro/Dezembro (ou qualquer outro ajuste por mês/faixa).</p>

<h3>Regras cadastradas</h3>
<table>
  <thead><tr><th>Mês</th><th>Até pessoas</th><th>Base</th><th>Hora extra</th></tr></thead>
  <tbody>
  <?php foreach ($rules as $r): ?>
    <tr>
      <td><?= h($r['month_from']) ?>–<?= h($r['month_to']) ?></td>
      <td><?= h($r['people_max']) ?></td>
      <td>R$ <?= number_format((int)$r['base_price'],2,',','.') ?></td>
      <td>R$ <?= number_format((int)$r['extra_hour_price'],2,',','.') ?>/h</td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<h3>Adicionar regra</h3>
<form method="post" action="<?= BASE_URL ?>/admin/precos">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
  <div class="grid3">
    <div>
      <label>Mês de</label>
      <input type="number" name="month_from" min="1" max="12" value="11" required>
    </div>
    <div>
      <label>Até mês</label>
      <input type="number" name="month_to" min="1" max="12" value="12" required>
    </div>
    <div>
      <label>Até pessoas</label>
      <input type="number" name="people_max" value="50" required>
    </div>
  </div>
  <div class="grid">
    <div>
      <label>Preço base (08–18)</label>
      <input type="number" name="base_price" required>
    </div>
    <div>
      <label>Preço hora extra</label>
      <input type="number" name="extra_hour_price" required>
    </div>
  </div>
  <button type="submit">Adicionar</button>
</form>
<p><a href="<?= BASE_URL ?>/admin">Voltar</a></p>
