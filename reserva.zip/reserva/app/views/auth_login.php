<?php $title = $title ?? 'Login'; ?>
<h1>Login</h1>
<form method="post" action="<?= BASE_URL ?>/login">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
  <label>Email</label>
  <input name="email" type="email" required>
  <label>Senha</label>
  <input name="password" type="password" required>
  <button type="submit">Entrar</button>
</form>
