<?php $u = current_user(); ?>
<h1>Meu perfil</h1>
<p class="muted">Por segurança, a senha atual não é exibida. Você pode definir uma nova senha abaixo.</p>
<p><strong>Nome:</strong> <?= h($u['name'] ?? '') ?><br>
<strong>Email:</strong> <?= h($u['email'] ?? '') ?><br>
<strong>Perfil:</strong> <?= h($u['role'] ?? '') ?></p>

<h2>Trocar senha</h2>
<form method="post" action="<?= BASE_URL ?>/perfil">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
  <label>Nova senha (mínimo 8 caracteres)</label>
  <input type="password" name="new_password" required>
  <button type="submit">Salvar</button>
</form>
