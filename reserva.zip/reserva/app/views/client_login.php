<h1>Entrar para efetivar</h1>
<p class="muted">Faça login para concluir a reserva. Se ainda não tem conta, crie em 30 segundos.</p>

<div class="grid">
  <form method="post" action="<?= BASE_URL ?>/cliente/login">
    <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
    <label>Email</label>
    <input name="email" type="email" required>
    <label>Senha</label>
    <input name="password" type="password" required>
    <div style="margin-top:12px;">
      <button type="submit">Entrar</button>
    </div>
  </form>

  <form method="post" action="<?= BASE_URL ?>/cliente/cadastro">
    <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
    <label>Nome completo</label>
    <input name="name" required>
    <label>Email</label>
    <input name="email" type="email" required>
    <label>WhatsApp</label>
    <input name="phone" required>
    <label>Crie uma senha (mín. 6)</label>
    <input name="password" type="password" required minlength="6">
    <div style="margin-top:12px;">
      <button type="submit">Criar conta</button>
    </div>
  </form>
</div>
