\
<?php
// Compatível com rotas antigas (ym) e novas (m)
$ym = $ym ?? ($_GET['ym'] ?? ($_GET['m'] ?? date('Y-m')));
if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m');

$today = date('Y-m-d');

[$y,$m] = array_map('intval', explode('-', $ym));
$monthNames = [1=>'Janeiro',2=>'Fevereiro',3=>'Março',4=>'Abril',5=>'Maio',6=>'Junho',7=>'Julho',8=>'Agosto',9=>'Setembro',10=>'Outubro',11=>'Novembro',12=>'Dezembro'];
$title = ($monthNames[$m] ?? 'Mês') . ' de ' . $y;

$first = new DateTime(sprintf('%04d-%02d-01', $y, $m));
$daysInMonth = (int)$first->format('t');
$startDow = (int)$first->format('N'); // 1=Seg..7=Dom

$prevYm = (clone $first)->modify('-1 month')->format('Y-m');
$nextYm = (clone $first)->modify('+1 month')->format('Y-m');

// mapa de datas indisponíveis (pendente/confirmada)
$unavail = [];
foreach (($bookings ?? []) as $b) {
  $st = $b['status'] ?? '';
  if ($st === 'PENDING' || $st === 'CONFIRMED') {
    $unavail[$b['date']] = true;
  }
}
?>

<style>
body{background:#ffffff !important; color:#0b1220 !important;}
header, .header, nav, .nav, .logo, .brand, .top, .masthead, .site-title, .site-subtitle{display:none !important;}

.cal-card{
  max-width:1120px;
  margin: 16px auto;
  padding: 16px;
  border: 1px solid rgba(0,0,0,.10);
  border-radius: 22px;
  box-shadow: 0 18px 40px rgba(0,0,0,.08);
  background:#f3f4f6;
}
.cal-nav{
  display:grid;
  grid-template-columns: 1fr auto 1fr;
  align-items:center;
  gap:12px;
  margin: 6px 0 14px 0;
}
.cal-title{
  text-align:center;
  font-weight:900;
  color:#0b1220;
  font-size:20px;
}
.btn{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  padding:10px 12px;
  border-radius:12px;
  text-decoration:none;
  font-weight:800;
  border:1px solid rgba(0,0,0,.18);
  background:#ffffff;
  color:#0b1220;
}
.cal-head{
  display:grid;
  grid-template-columns: repeat(7, minmax(0,1fr));
  gap:6px;
  margin-bottom:10px;
  font-weight:800;
}
.cal-head div{text-align:center; opacity:.75; font-size:12px;}

.cal{display:grid; grid-template-columns: repeat(7, minmax(0,1fr)); gap:6px;}
.day{
  overflow:hidden;
  border-radius:12px;
  border:2px solid rgba(0,0,0,.14);
  min-height:56px;
  padding:8px;
  background:#fff;
  position:relative;
}
.day.empty{background:transparent;border-color:transparent;}
.day .n{white-space:nowrap; line-height:1.1; font-size:15px; font-weight:900;}
.day .s{
  position:absolute;
  left:8px; right:8px; bottom:7px;
  text-align:center;
  font-size:10px;
  padding:4px 6px;
  border-radius:10px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  border:1px solid rgba(0,0,0,.14);
  background: rgba(0,0,0,.03);
}

a.day{display:block; text-decoration:none; color:inherit; cursor:pointer;}
.day.avail{border-color: rgba(16,185,129,.55); background: rgba(16,185,129,.06);}
.day.avail .s{color:#065f46; border-color: rgba(16,185,129,.45); background: rgba(16,185,129,.10);}
.day.unavail{border-color: rgba(220,38,38,.55); background: rgba(220,38,38,.06);}
.day.unavail .s{color:#7f1d1d; border-color: rgba(220,38,38,.45); background: rgba(220,38,38,.10);}

@media (min-width: 561px){
  .cal, .cal-head{gap:10px;}
  .cal-head div{font-size:14px;}
  .day{min-height:92px; padding:10px; border-radius:14px;}
  .day .n{font-size:22px;}
  .day .s{
    left:50%; right:auto; bottom:auto; top:58%;
    transform: translate(-50%, -50%);
    font-size:13px; padding:6px 12px; border-radius:999px;
  }
}
@media (max-width: 560px){
  .cal-card{margin:10px; padding:12px; border-radius:18px;}
  .cal-nav{grid-template-columns: 1fr; gap:10px;}
  .cal-title{order:-1; font-size:18px;}
  .btn{width:100%;}
}
</style>

<div class="cal-card">
  <div class="cal-nav">
    <a class="btn" href="?ym=<?= h($prevYm) ?>">◀ Mês anterior</a>
    <div class="cal-title"><?= h($title) ?></div>
    <a class="btn" href="?ym=<?= h($nextYm) ?>">Próximo mês ▶</a>
  </div>

  <div class="cal-head">
    <div>Seg</div><div>Ter</div><div>Qua</div><div>Qui</div><div>Sex</div><div>Sáb</div><div>Dom</div>
  </div>

  <div class="cal">
    <?php for ($i=1; $i<$startDow; $i++): ?>
      <div class="day empty"></div>
    <?php endfor; ?>

    <?php for ($d=1; $d<=$daysInMonth; $d++):
      $dateStr = sprintf('%04d-%02d-%02d', $y, $m, $d);
      $isPastOrToday = ($dateStr <= $today);
      $isBooked = isset($unavail[$dateStr]);
      $isUnavailable = $isPastOrToday || $isBooked;
    ?>
      <?php if (!$isUnavailable): ?>
        <a class="day avail" href="<?= BASE_URL ?>/reservar?date=<?= h($dateStr) ?>">
          <div class="n"><?= (int)$d ?></div>
          <span class="s">Disponível</span>
        </a>
      <?php else: ?>
        <div class="day unavail">
          <div class="n"><?= (int)$d ?></div>
          <span class="s">Indisponível</span>
        </div>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
</div>
