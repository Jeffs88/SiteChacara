<?php
$client = $client ?? null;
$quote = $quote ?? null;
?>
<h1>Efetivar reserva</h1>
<p class="muted">Revise seus dados e envie o documento para concluir a pré-reserva.</p>

<?php if (!$quote): ?>
  <p>Seu orçamento não foi encontrado. Volte e gere novamente.</p>
<?php else: ?>
  <div class="pricebox" style="padding:12px; margin:14px 0;">
    <div class="muted">Orçamento selecionado</div>
    <div style="font-size:18px; font-weight:900;">
      <?= h($quote['date']) ?> • até <?= h($quote['end_hour']) ?>:00 • <?= h($quote['people_label']) ?>
    </div>
    <div class="note"><?= h($quote['addons_text']) ?></div>
    <div style="margin-top:8px; font-size:22px; font-weight:900;">R$ <?= number_format((float)$quote['total'],2,',','.') ?></div>
  </div>

  <form method="post" action="<?= BASE_URL ?>/finalizar" enctype="multipart/form-data">
    <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">

    <div class="grid">
      <div>
        <label>Nome completo</label>
        <input name="client_name" required value="<?= h($client['name'] ?? '') ?>">
      </div>
      <div>
        <label>CPF</label>
        <input name="client_cpf" required placeholder="000.000.000-00">
      </div>
    </div>

    <div class="grid">
      <div>
        <label>RG (opcional)</label>
        <input name="client_rg" placeholder="Somente números">
      </div>
      <div>
        <label>Endereço completo</label>
        <input name="client_address" required placeholder="Rua, nº, bairro, cidade/UF">
      </div>
    </div>

    <div class="grid">
      <div>
        <label>Email</label>
        <input name="client_email" type="email" required value="<?= h($client['email'] ?? '') ?>">
      </div>
      <div>
        <label>WhatsApp/Telefone</label>
        <input name="client_phone" required value="<?= h($client['phone'] ?? '') ?>">
      </div>
    </div>

    <label>Documento pessoal (foto/arquivo)</label>
    <input type="file" name="document" accept=".jpg,.jpeg,.png,.pdf" required>

    <button type="submit">Enviar pré-reserva</button>
  </form>
<?php endif; ?>
