\
<?php
$prefillDate = $_GET['date'] ?? '';
if ($prefillDate && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $prefillDate)) $prefillDate = '';
$minDate = date('Y-m-d', strtotime('+1 day'));
?>

<h1>Orçamento</h1>
<p class="muted">Escolha a data, quantidade de pessoas e horário. O valor total aparece no final. Depois você pode efetivar a reserva.</p>

      <ul style="margin:0; padding-left:18px; line-height:1.7;">
        <li>Churrasqueira + grelha + espetos</li>
        <li>2 geladeiras</li>
        <li>Fogão industrial 4 bocas + micro-ondas</li>
        <li>Freezer horizontal</li>
        <li>12 mesas e 48 cadeiras plásticas</li>
        <li>Mesa e bancos de madeira</li>
        <li>Banheiros: 1 PCD, 2 masculinos e 2 femininos</li>
      </ul>
    </div>

    <div>
      <div style="font-weight:900; margin-bottom:6px;">🌿 Área externa e lazer</div>
      <ul style="margin:0; padding-left:18px; line-height:1.7;">
        <li>🍖 Quiosque com churrasqueira</li>
        <li>🏊‍♀️ Piscina adulto e infantil</li>
        <li>🛝 Parquinho + casinha de boneca</li>
        <li>👰‍♀️ Pergolado para fotos</li>
        <li>🔥 Espaço para costela fogo de chão</li>
        <li>⚽ Campo de futebol</li>
        <li>🏐 Campo de vôlei</li>
        <li>🚗 Estacionamento no local</li>
      </ul>
    </div>
  </div>
</div>

<form id="orcForm" method="post" action="<?= BASE_URL ?>/efetivar" class="card" style="padding:14px;">
  <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">

  <div class="grid">
    <div>
      <label>Data do evento</label>
      <input id="date" type="date" name="date" required min="<?= h($minDate) ?>" value="<?= h($prefillDate) ?>">
      <div class="note">Datas anteriores e o dia de hoje ficam indisponíveis.</div>
    </div>

    <div>
      <label>Quantidade de pessoas (crianças acima de 2 anos contam)</label>
      <select id="people" name="people" required>
        <option value="">Selecione</option>
        <option value="50">Até 50</option>
        <option value="100">Até 100</option>
        <option value="150">Até 150</option>
        <option value="200">Até 200</option>
        <option value="250">Até 250</option>
        <option value="251">Mais de 250</option>
      </select>
    </div>
  </div>

  <div class="grid">
    <div>
      <label>Horário limite de término</label>
      <select id="end_hour" name="end_hour" required>
        <option value="18">18:00</option>
        <option value="19">19:00</option>
        <option value="20">20:00</option>
        <option value="21">21:00</option>
        <option value="22">22:00</option>
      </select>
    </div>

    <div>
      <label>Tipo de evento</label>
      <select id="type_event" name="type_event" required>
        <option value="">Selecione</option>
        <option>Aniversário</option>
        <option>Casamento</option>
        <option>Confraternização</option>
        <option>Churrasco</option>
        <option>Batizado</option>
        <option>Formatura</option>
        <option>Outro</option>
      </select>
    </div>
  </div>

  <!-- Valor total no FINAL -->
  <div class="pricebox" style="padding:12px; margin:14px 0 0 0;">
    <div class="muted">Valor total da locação</div>
    <div id="totalLabel" style="font-size:26px; font-weight:900;">Selecione a data e opções</div>
    <div class="note" id="breakdown"></div>
  </div>

  <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
    <button type="submit" id="btnEfetivar" disabled>Efetivar reserva</button>
    <span class="note" id="hint">Preencha data, pessoas e horário para liberar.</span>
  </div>
</form>

<script>
(function(){
  const dateEl = document.getElementById('date');
  const peopleEl = document.getElementById('people');
  const endEl = document.getElementById('end_hour');
  const totalLabel = document.getElementById('totalLabel');
  const breakdown = document.getElementById('breakdown');
  const btn = document.getElementById('btnEfetivar');
  const hint = document.getElementById('hint');

  async function refresh(){
    const date = dateEl.value;
    const people = peopleEl.value;
    const end = endEl.value;

    if(!date || !people || !end){
      totalLabel.textContent = 'Selecione a data e opções';
      breakdown.textContent = '';
      btn.disabled = true;
      hint.textContent = 'Preencha data, pessoas e horário para liberar.';
      return;
    }

    const r = await fetch(`<?= BASE_URL ?>/api/price?date=${encodeURIComponent(date)}&people=${encodeURIComponent(people)}&end_hour=${encodeURIComponent(end)}`);
    const j = await r.json();
    if(!j.ok){
      totalLabel.textContent = 'Não foi possível calcular';
      breakdown.textContent = j.error || '';
      btn.disabled = true;
      return;
    }

    const total = (parseInt(j.total_suggested,10) || 0);

    totalLabel.textContent = 'R$ ' + total.toLocaleString('pt-BR',{minimumFractionDigits:2, maximumFractionDigits:2});
    breakdown.textContent =
      `Base: R$ ${parseInt(j.base_price,10).toLocaleString('pt-BR',{minimumFractionDigits:2})} | ` +
      `Horas extras: ${j.extra_hours} x R$ ${parseInt(j.extra_rate,10).toLocaleString('pt-BR',{minimumFractionDigits:2})}`;

    btn.disabled = false;
    hint.textContent = 'Ao clicar em "Efetivar reserva", você fará login/cadastro para concluir.';
  }

  ['change','input'].forEach(ev=>{
    dateEl.addEventListener(ev, refresh);
    peopleEl.addEventListener(ev, refresh);
    endEl.addEventListener(ev, refresh);
  });
  refresh();
})();
</script>
