<h1>Preços (referência)</h1>

<p><span class="tag">Jan–Out</span></p>
<ul>
  <li><strong>Até 50 pessoas:</strong> R$ 1.200 (08:00–18:00) + R$ 125/h extra (até 22:00)</li>
  <li><strong>Até 100 pessoas:</strong> R$ 1.600 (08:00–18:00) + R$ 135/h extra (até 22:00)</li>
  <li><strong>Até 200 pessoas:</strong> R$ 2.000 (08:00–18:00) + R$ 150/h extra (até 22:00)</li>
</ul>

<p><span class="tag">Nov–Dez</span> Valores podem variar. Consulte na reserva ou fale conosco.</p>

<hr>
<p class="muted">Crianças acima de 2 anos contam na quantidade total.</p>
