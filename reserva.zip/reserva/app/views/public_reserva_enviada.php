<style>
.enviada-card{max-width:820px;margin:18px auto;background:#f3f4f6;border:1px solid rgba(0,0,0,.10);border-radius:22px;padding:16px;}
</style>
<div class="enviada-card">
<h1>Pré-reserva enviada</h1>

<?php if ($b): ?>
  <p>Recebemos sua solicitação para <strong><?= h(date('d/m/Y', strtotime($b['date']))) ?></strong>.</p>
  <p class="muted">Status: <?= h($b['status']) ?>. Confirmaremos o quanto antes.</p>
<?php else: ?>
  <p>Recebemos sua solicitação. Confirmaremos o quanto antes.</p>
<?php endif; ?>

<p><a href="<?= BASE_URL ?>/disponibilidade">Ver disponibilidade</a></p>

</div>
