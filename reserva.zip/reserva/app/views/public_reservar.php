\
<?php
$prefill_date = '';
if (isset($_GET['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date'])) {
  $prefill_date = $_GET['date'];
}
?>

<style>
/* Reset leve para evitar "desconfigurar" dentro do WordPress/tema */
*{ box-sizing:border-box; }
.reserva-wrap{ max-width:980px; margin:16px auto; padding:0 12px; }
.reserva-card{
  background:#f3f4f6;
  border:1px solid rgba(0,0,0,.12);
  border-radius:22px;
  padding:18px;
  color:#0b1220;
  box-shadow:0 18px 40px rgba(0,0,0,.08);
}
.reserva-card h1{ margin:0 0 6px 0; color:#0b1220; font-size:32px; line-height:1.1; }
.reserva-card .muted{ color:rgba(11,18,32,.65); margin:0 0 14px 0; }

.reserva-card label{
  font-weight:800;
  display:block;
  margin-top:12px;
  margin-bottom:6px;
  color:#0b1220;
}
.reserva-card input,
.reserva-card select,
.reserva-card textarea{
  width:100%;
  display:block;
  padding:12px 12px;
  border-radius:14px;
  border:1px solid rgba(0,0,0,.18);
  background:#fff;
  color:#0b1220;
  min-height:44px;
}
.reserva-card input[type="checkbox"]{ min-height:auto; }
.reserva-card input[type="file"]{ padding:10px; }

.grid2{
  display:grid;
  grid-template-columns: minmax(0,1fr) minmax(0,1fr);
  gap:16px;
  align-items:start;
}
@media (max-width: 820px){
  .reserva-card h1{ font-size:28px; }
}
@media (max-width: 720px){
  .grid2{ grid-template-columns: 1fr; gap:12px; }
  .reserva-card{ padding:14px; border-radius:18px; }
}

.section{
  background:#ffffff;
  border:1px solid rgba(0,0,0,.10);
  border-radius:18px;
  padding:14px;
  margin-top:16px;
}
.section h3{ margin:0 0 10px 0; font-size:18px; }

.choice{
  display:flex;
  gap:12px;
  align-items:flex-start;
  padding:12px;
  border-radius:16px;
  border:1px solid rgba(0,0,0,.10);
  background:rgba(0,0,0,.02);
  margin-top:10px;
}
.choice input{ width:18px; height:18px; margin-top:3px; flex:0 0 auto; }
.choice .name{ font-weight:900; }
.choice .price{ opacity:.75; font-size:13px; margin-top:2px; }
.choice .controls{ margin-top:8px; }

.total-box{
  margin:18px 0 12px 0;
  padding:16px 14px;
  border-radius:18px;
  background:#ffffff;
  border:2px solid rgba(16,185,129,.85);
  font-size:20px;
  font-weight:900;
  text-align:center;
}
.btn-primary{
  width:100%;
  padding:13px 14px;
  border-radius:14px;
  background:#10b981;
  color:#06210f;
  font-weight:900;
  border:1px solid rgba(0,0,0,.10);
  cursor:pointer;
}
.btn-primary:hover{ filter:brightness(0.98); }
.small{ font-size:13px; color:rgba(11,18,32,.65); margin-top:8px; }
</style>

<div class="reserva-wrap">
  <div class="reserva-card">
    <h1>Reserva</h1>
    <p class="muted">Preencha para solicitar a pré-reserva. Depois você recebe o contrato para assinatura.</p>

    <form method="post" action="<?= BASE_URL ?>/reservar" enctype="multipart/form-data">
      <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">

      <div class="grid2">
        <div>
          <label>Data do evento</label>
          <input type="date" name="date" id="date" required value="<?= h($prefill_date) ?>">
        </div>
        <div>
          <label>Quantidade de pessoas</label>
          <select name="people" id="people" required>
            <option value="">Selecione</option>
            <option value="50">Até 50</option>
            <option value="100">Até 100</option>
            <option value="150">Até 150</option>
            <option value="200">Até 200</option>
            <option value="250">Até 250</option>
            <option value="251">Mais de 250</option>
          </select>
          <div class="small">Obs.: crianças acima de 2 anos contam.</div>
        </div>
      </div>

      <div class="grid2">
        <div>
          <label>Horário limite de término</label>
          <select name="end_hour" id="end_hour" required>
            <option value="18">18:00</option>
            <option value="19">19:00</option>
            <option value="20">20:00</option>
            <option value="21">21:00</option>
            <option value="22">22:00</option>
          </select>
        </div>
        <div>
          <label>Tipo de evento</label>
          <select id="event_type" required>
            <option value="">Selecione</option>
            <option value="Aniversário">Aniversário</option>
            <option value="Casamento">Casamento</option>
            <option value="Confraternização">Confraternização</option>
            <option value="Chá revelação">Chá revelação</option>
            <option value="Festa infantil">Festa infantil</option>
            <option value="Outros">Outros</option>
          </select>
        </div>
      </div>

      <div class="grid2">
        <div>
          <label>Nome completo</label>
          <input name="client_name" required>
        </div>
        <div>
          <label>Email</label>
          <input name="client_email" type="email" required>
        </div>
      </div>

      <label>WhatsApp/Telefone</label>
      <input name="client_phone" required>

      <div class="section">
        <h3>Adicionais</h3>

        <div class="grid2">
          <div>
            <div class="small"><strong>Taxa adicional</strong></div>

            <label class="choice">
  <input type="checkbox" class="extra" id="mesa_chk" data-name="Mesa com 4 cadeiras" data-price="20">
  <div style="flex:1">
    <div class="name">Mesa com 4 cadeiras</div>
    <div class="price">R$ 20,00 cada</div>
    <div class="controls">
      <label style="margin:0; font-weight:800; font-size:13px;">Quantidade</label>
      <input type="number" min="1" value="1" id="mesa_qtd" style="max-width:120px; width:120px" disabled>
    </div>
  </div>
</label>
          </div>
        </div>

        <input type="hidden" name="additional_items" id="additional_items" value="">
      </div>

      <div class="section">
        <h3>Documentos</h3>
        <div class="grid2">
          <div>
            <label>Documento pessoal (foto/arquivo)</label>
            <input type="file" name="document" accept=".jpg,.jpeg,.png,.pdf" required>
          </div>
          <div>
            <label>Comprovante de endereço (foto/arquivo)</label>
            <input type="file" name="proof_address" accept=".jpg,.jpeg,.png,.pdf">
          </div>
        </div>
        <div class="small">O comprovante de endereço é recomendado. Se preferir, você pode enviar depois pelo WhatsApp.</div>
      </div>

      <div class="total-box">
        Valor total da locação<br>
        <span id="total">—</span>
      </div>

      <button class="btn-primary" type="submit">Enviar Pré-reserva</button>
      <div class="small">Ao enviar, você concorda com o envio dos dados para elaboração do contrato.</div>
    </form>
  </div>
</div>

<script>
(function(){
  const fmt = v => (typeof v === 'number' && !Number.isNaN(v))
    ? v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})
    : '—';

  const elDate = document.getElementById('date');
  const elPeople = document.getElementById('people');
  const elEnd = document.getElementById('end_hour');
  const elTotal = document.getElementById('total');
  const elHidden = document.getElementById('additional_items');
  const elEvent = document.getElementById('event_type');
  const mesaChk = document.getElementById('mesa_chk');
  const mesaQtd = document.getElementById('mesa_qtd');

  function extrasSum(){
    let total = 0;
    let labels = [];

    document.querySelectorAll('input.extra:checked').forEach(cb=>{
      const unit = parseFloat(cb.dataset.price || '0') || 0;
      let qty = 1;

      if (cb.id === 'mesa_chk' && mesaQtd){
        qty = Math.max(1, parseInt(mesaQtd.value || '1', 10));
      }

      const line = unit * qty;
      total += line;

      const name = cb.dataset.name || 'Adicional';
      if (qty > 1) labels.push(`${qty}x ${name}`);
      else labels.push(name);
    });

    // tipo do evento vai junto para aparecer no Admin/contrato (campo additional_items)
    const ev = (elEvent && elEvent.value) ? ('Tipo de evento: ' + elEvent.value) : '';

    let txt = '';
    if (ev) txt += ev;
    if (labels.length) txt += (txt ? ' | ' : '') + labels.join(', ');
    if (elHidden) elHidden.value = txt;

    return total;
  }

  async function basePrice(){
    const date = elDate?.value || '';
    const people = elPeople?.value || '';
    const end = elEnd?.value || '';
    if(!date || !people || !end) return null;

    try{
      const r = await fetch(`<?= BASE_URL ?>/api/price?date=${encodeURIComponent(date)}&people=${encodeURIComponent(people)}&end=${encodeURIComponent(end)}`, {headers:{'Accept':'application/json'}});
      const j = await r.json();
      if(!j || !j.ok) return null;
      return Number(j.total);
    }catch(e){
      return null;
    }
  }

  async function updateTotal(){
    // habilita/desabilita quantidade de mesa
    if (mesaChk && mesaQtd) mesaQtd.disabled = !mesaChk.checked;

    const add = extrasSum();
    const base = await basePrice();
    if(base === null){
      elTotal.textContent = '—';
      return;
    }
    elTotal.textContent = fmt(base + add);
  }

  // listeners
  ['change','input'].forEach(ev=>{
    elDate?.addEventListener(ev, updateTotal);
    elPeople?.addEventListener(ev, updateTotal);
    elEnd?.addEventListener(ev, updateTotal);
    elEvent?.addEventListener(ev, updateTotal);
  });
  document.querySelectorAll('input.extra').forEach(cb=>cb.addEventListener('change', updateTotal));
  mesaQtd?.addEventListener('input', updateTotal);

  updateTotal();
})();
</script>