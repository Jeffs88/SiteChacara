<?php
// === CONFIGURAÇÕES PRINCIPAIS ===

// URL base do sistema (ajuste para o seu domínio)
define('BASE_URL', 'https://www.espacorecantoverde.com.br/reserva');

// Banco de dados (MySQL)
define('DB_HOST', 'localhost');
define('DB_NAME', 'tecn7826_reservas_recanto');
define('DB_USER', 'tecn7826_reservas_user');
define('DB_PASS', 'J82520190*');

// Upload/armazenamento
define('STORAGE_PATH', __DIR__ . '/../storage');
define('UPLOAD_PATH', STORAGE_PATH . '/uploads');
define('CONTRACT_PATH', STORAGE_PATH . '/contracts');
define('LOG_PATH', STORAGE_PATH . '/logs');

// BeSign (preencher se for integrar via API)
define('BESIGN_ENABLED', false);
define('BESIGN_API_BASE', 'https://api.besign.com.br'); // ajuste conforme sua conta/doc
define('BESIGN_API_TOKEN', 'COLE_AQUI_SEU_TOKEN');
