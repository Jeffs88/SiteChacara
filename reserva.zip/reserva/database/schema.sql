-- Banco: MySQL/MariaDB
-- Tabelas do sistema de reservas

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('ADMIN','CARETAKER') NOT NULL DEFAULT 'CARETAKER',
  created_at DATETIME NULL,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  status ENUM('PENDING','CONFIRMED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  date DATE NOT NULL,
  start_time TIME NOT NULL DEFAULT '08:00:00',
  end_time TIME NOT NULL,
  people INT NOT NULL,
  kids_over2_counted TINYINT(1) NOT NULL DEFAULT 1,

  client_name VARCHAR(150) NOT NULL,
  client_cpf VARCHAR(30) NULL,
  client_rg VARCHAR(30) NULL,
  client_address VARCHAR(255) NULL,

  client_email VARCHAR(190) NOT NULL,
  client_phone VARCHAR(60) NOT NULL,
  type_event VARCHAR(80) NULL,
  notes TEXT NULL,

  additional_items TEXT NULL,
  addons_json TEXT NULL,
  notes TEXT NULL,

  suggested_total INT NULL,
  total_price INT NULL,
  entry_paid INT NULL,
  remaining INT NULL,
  paid_status ENUM('NAO','PARCIAL','SIM') NULL,

  document_path VARCHAR(255) NULL,
  contract_path VARCHAR(255) NULL,

  created_at DATETIME NULL,
  updated_at DATETIME NULL,

  INDEX idx_date (date),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS price_rules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  month_from TINYINT NOT NULL,
  month_to TINYINT NOT NULL,
  people_max INT NOT NULL,
  base_price INT NOT NULL,
  extra_hour_price INT NOT NULL,
  created_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Usuários iniciais
INSERT INTO users (name, email, password_hash, role, created_at)
VALUES
  ('Administrador', 'admin@recantoverde.local', '$2y$10$uJZ3x9A8GQpYzS6rYfE.6eGkHcyWq5oQj7vGJj8x1QfU6S8p4v6tC', 'ADMIN', NOW()),
  ('Caseiro', 'caseiro@recantoverde.local', '$2y$10$wM5bN7KXlQH0q3v6A3W0fOiJQG7m2f8lA0c1D9bV3j7l2V9X0Qp9y', 'CARETAKER', NOW());

-- As senhas acima correspondem (aprox.) a:
-- Admin@12345 e Caseiro@12345
-- (se não bater por qualquer motivo, você pode entrar e trocar, ou atualizar hashes no DB usando password_hash no PHP).
