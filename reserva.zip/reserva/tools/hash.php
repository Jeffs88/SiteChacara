<?php
// Rode localmente ou temporariamente no servidor e apague depois.
$pwd = $argv[1] ?? ($_GET['p'] ?? 'senha');
echo password_hash($pwd, PASSWORD_DEFAULT);
